var searchData=
[
  ['tag',['Tag',['../classodil_1_1_tag.html#a9bb871a3dfd0869c38137d1d75be03f7',1,'odil::Tag::Tag(uint16_t group, uint16_t element)'],['../classodil_1_1_tag.html#a95e3b016d899e71facfcd61078377cad',1,'odil::Tag::Tag(uint32_t tag)'],['../classodil_1_1_tag.html#aab3feea935d659eee7098b8486445774',1,'odil::Tag::Tag(std::string const &amp;name)'],['../classodil_1_1_tag.html#a0507475eb88b73ad520c78af799adee1',1,'odil::Tag::Tag(char const *name)']]]
];
