var searchData=
[
  ['stream',['stream',['../classodil_1_1_reader.html#a7f39807658e83f700107752e690ff93f',1,'odil::Reader::stream()'],['../classodil_1_1_writer.html#a4841cfcf0279b63f76225cf5185dc47f',1,'odil::Writer::stream()']]]
];
