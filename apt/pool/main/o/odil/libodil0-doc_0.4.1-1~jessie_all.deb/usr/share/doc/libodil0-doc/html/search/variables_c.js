var searchData=
[
  ['vr',['vr',['../classodil_1_1_element.html#a2a15e3a2e95803b2f44a009dbb9f2a65',1,'odil::Element']]]
];
