var searchData=
[
  ['id',['id',['../structodil_1_1_association_parameters_1_1_presentation_context.html#aa4fe39269a1cd9373601aec2e4c0694b',1,'odil::AssociationParameters::PresentationContext']]],
  ['item_5fencoding',['item_encoding',['../classodil_1_1_basic_directory_creator.html#a9258d6c98ab698cb83f1fa5b80167a44',1,'odil::BasicDirectoryCreator::item_encoding()'],['../classodil_1_1_writer.html#aead4664ef2426ad57f342cb2ad63650b',1,'odil::Writer::item_encoding()']]]
];
