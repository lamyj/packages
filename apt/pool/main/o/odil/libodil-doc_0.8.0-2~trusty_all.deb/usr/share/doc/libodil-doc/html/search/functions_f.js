var searchData=
[
  ['tag',['Tag',['../classodil_1_1_tag.html#a9bb871a3dfd0869c38137d1d75be03f7',1,'odil::Tag::Tag(uint16_t group, uint16_t element)'],['../classodil_1_1_tag.html#a00d457758066374a346990d5c56b6aaf',1,'odil::Tag::Tag(uint32_t tag=0)'],['../classodil_1_1_tag.html#a7218a485faff14459fd969d2fa5ff16a',1,'odil::Tag::Tag(std::string const &amp;string)'],['../classodil_1_1_tag.html#ad069a30eba4091c37b63b37075ff9ce3',1,'odil::Tag::Tag(char const *string)']]]
];
