#include <iostream>

#include "odil/Association.h"
#include "odil/DataSet.h"
#include "odil/FindSCU.h"
#include "odil/GetSCU.h"
#include "odil/registry.h"

void print_informations(odil::DataSet const & response)
{
    auto const name = response.has("PatientName")?
        response.as_string("PatientName", 0):"(no name)";
    auto const study = response.has("StudyDescription")?
        response.as_string("StudyDescription", 0):"(no study description)";
    auto const series = response.has("SeriesDescription")?
        response.as_string("SeriesDescription", 0):"(no series description)";
    auto const instance = response.has("InstanceNumber")?
        response.as_int("InstanceNumber", 0):(-1);
    std::cout
        << name << ": " << study << " / " << series << ": " << instance << "\n";
}

int main()
{
    odil::Association association;
    association.set_peer_host("184.73.255.26");
    association.set_peer_port(11112);
    association.update_parameters()
        .set_calling_ae_title("myself")
        .set_called_ae_title("AWSPIXELMEDPUB")
        .set_presentation_contexts({
            {
                1, odil::registry::StudyRootQueryRetrieveInformationModelFIND,
                { odil::registry::ImplicitVRLittleEndian }, true, false
            },
            {
                3, odil::registry::StudyRootQueryRetrieveInformationModelGET,
                { odil::registry::ImplicitVRLittleEndian }, true, false
            },
            {
                5, odil::registry::MRImageStorage,
                { odil::registry::ImplicitVRLittleEndian }, false, true
            },
            {
                7, odil::registry::VerificationSOPClass,
                { odil::registry::ImplicitVRLittleEndian }, true, false
            }
        });
    
    association.associate();

    odil::FindSCU find_scu(association);
    find_scu.set_affected_sop_class(
        odil::registry::StudyRootQueryRetrieveInformationModelFIND);

    odil::DataSet query;
    query.add("QueryRetrieveLevel", { "STUDY" });
    query.add("StudyInstanceUID");

    auto const studies = find_scu.find(query);
    odil::DataSet series;
    for(auto const & study: studies)
    {
        if(!study.has("StudyInstanceUID"))
        {
            continue;
        }

        query = odil::DataSet();
        query.add("QueryRetrieveLevel", {"SERIES"});
        query.add("Modality", {"MR"});
        query.add("StudyInstanceUID", study.as_string("StudyInstanceUID"));
        query.add("SeriesInstanceUID");

        auto const study_series = find_scu.find(query);

        if(!study_series.empty())
        {
            series = study_series[0];
            break;
        }
    }

    odil::GetSCU get_scu(association);
    get_scu.set_affected_sop_class(
        odil::registry::StudyRootQueryRetrieveInformationModelGET);
    
    query = odil::DataSet();
    query.add("QueryRetrieveLevel", { "SERIES" });
    query.add("StudyInstanceUID", series["StudyInstanceUID"]);
    query.add("SeriesInstanceUID", series["SeriesInstanceUID"]);

    std::cout << "--------\n";
    std::cout << "Callback\n";
    std::cout << "--------\n\n";
    
    get_scu.get(query, print_informations);
    
    std::cout << "\n";
    
    std::cout << "------\n";
    std::cout << "vector\n";
    std::cout << "------\n\n";
    
    auto const result = get_scu.get(query);
    for(auto const & dataset: result)
    {
        print_informations(dataset);
    }
    
    association.release();
}
