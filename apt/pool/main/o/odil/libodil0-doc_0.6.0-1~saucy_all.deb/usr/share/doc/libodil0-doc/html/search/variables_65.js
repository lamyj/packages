var searchData=
[
  ['element',['element',['../classodil_1_1_tag.html#a0393acf9ff1a8d80d462aad079eee0bf',1,'odil::Tag']]],
  ['explicit_5fvr',['explicit_vr',['../classodil_1_1_reader.html#a7ef998b42f1fe4115c5631fa458f427d',1,'odil::Reader::explicit_vr()'],['../classodil_1_1_writer.html#a0064dfe7e7c4463ac4fdf7f69121006b',1,'odil::Writer::explicit_vr()']]],
  ['extra_5frecord_5fkeys',['extra_record_keys',['../classodil_1_1_basic_directory_creator.html#aa8f3ab62d32bb64743425db88d896bfc',1,'odil::BasicDirectoryCreator']]]
];
