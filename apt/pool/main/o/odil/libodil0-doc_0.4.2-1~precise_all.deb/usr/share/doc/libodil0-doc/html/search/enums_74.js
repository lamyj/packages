var searchData=
[
  ['type',['Type',['../classodil_1_1_elements_dictionary_key.html#a00476507d06ed38282895077cc5785c6',1,'odil::ElementsDictionaryKey::Type()'],['../classodil_1_1_value.html#a7dce7c628fe81f1e3aa83939c2387364',1,'odil::Value::Type()']]]
];
