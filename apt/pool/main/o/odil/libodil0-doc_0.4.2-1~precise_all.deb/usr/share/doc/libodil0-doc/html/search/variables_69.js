var searchData=
[
  ['item_5fencoding',['item_encoding',['../classodil_1_1_basic_directory_creator.html#a9258d6c98ab698cb83f1fa5b80167a44',1,'odil::BasicDirectoryCreator::item_encoding()'],['../classodil_1_1_writer.html#aead4664ef2426ad57f342cb2ad63650b',1,'odil::Writer::item_encoding()']]]
];
