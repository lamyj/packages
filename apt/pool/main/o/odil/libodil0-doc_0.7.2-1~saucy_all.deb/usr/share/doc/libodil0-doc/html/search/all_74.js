var searchData=
[
  ['tag',['Tag',['../classodil_1_1_tag.html',1,'odil']]],
  ['tag',['Tag',['../classodil_1_1_tag.html#a9bb871a3dfd0869c38137d1d75be03f7',1,'odil::Tag::Tag(uint16_t group, uint16_t element)'],['../classodil_1_1_tag.html#a00d457758066374a346990d5c56b6aaf',1,'odil::Tag::Tag(uint32_t tag=0)'],['../classodil_1_1_tag.html#a7218a485faff14459fd969d2fa5ff16a',1,'odil::Tag::Tag(std::string const &amp;string)'],['../classodil_1_1_tag.html#ad069a30eba4091c37b63b37075ff9ce3',1,'odil::Tag::Tag(char const *string)']]],
  ['tojsonvisitor',['ToJSONVisitor',['../classodil_1_1_to_j_s_o_n_visitor.html',1,'odil']]],
  ['toxmlvisitor',['ToXMLVisitor',['../structodil_1_1_to_x_m_l_visitor.html',1,'odil']]],
  ['transfer_5fsyntax',['transfer_syntax',['../classodil_1_1_reader.html#a6c4105a3e8661fcb89db67d2b8f8094f',1,'odil::Reader']]],
  ['transfer_5fsyntaxes',['transfer_syntaxes',['../structodil_1_1_association_parameters_1_1_presentation_context.html#acca074b98b0959c9a7cfd4fb034898f2',1,'odil::AssociationParameters::PresentationContext']]],
  ['type',['Type',['../structodil_1_1_association_parameters_1_1_user_identity.html#a2fd92c214b4f1369190c7e5e4e5accff',1,'odil::AssociationParameters::UserIdentity::Type()'],['../classodil_1_1_elements_dictionary_key.html#a00476507d06ed38282895077cc5785c6',1,'odil::ElementsDictionaryKey::Type()'],['../classodil_1_1_value.html#a7dce7c628fe81f1e3aa83939c2387364',1,'odil::Value::Type()'],['../structodil_1_1_association_parameters_1_1_user_identity.html#a1b7b5fb7f1e8ca706ff7d88c35bf3c29',1,'odil::AssociationParameters::UserIdentity::type()'],['../structodil_1_1_u_i_ds_dictionary_entry.html#ae02685a0d0d6b42363620a787b69e93c',1,'odil::UIDsDictionaryEntry::type()']]]
];
