var searchData=
[
  ['result',['Result',['../classodil_1_1_association.html#a6e959e9bc86521f988f7c1ddfe78fb1d',1,'odil::Association::Result()'],['../structodil_1_1_association_parameters_1_1_presentation_context.html#a4db2293d9a0d09a63ce3919c545d8b59',1,'odil::AssociationParameters::PresentationContext::Result()']]],
  ['resultsource',['ResultSource',['../classodil_1_1_association.html#a3fb8fac21bb129360a860a01b4fb4e26',1,'odil::Association']]]
];
