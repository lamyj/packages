var searchData=
[
  ['basicdirectorycreator',['BasicDirectoryCreator',['../classodil_1_1_basic_directory_creator.html#acfbc5677aa1f1f3d2110c2a3f9daee43',1,'odil::BasicDirectoryCreator']]],
  ['begin',['begin',['../classodil_1_1_data_set.html#a2e7a22d0f856753de99e3ced035507d9',1,'odil::DataSet']]]
];
