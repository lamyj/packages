var searchData=
[
  ['rawelementsdictionaryentry',['RawElementsDictionaryEntry',['../structodil_1_1registry_1_1_raw_elements_dictionary_entry.html',1,'odil::registry']]],
  ['rawuidsdictionaryentry',['RawUIDsDictionaryEntry',['../structodil_1_1registry_1_1_raw_u_i_ds_dictionary_entry.html',1,'odil::registry']]],
  ['reader',['Reader',['../classodil_1_1_reader.html',1,'odil']]]
];
