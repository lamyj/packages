var searchData=
[
  ['datasets',['DataSets',['../classodil_1_1_value.html#a6233d10a60e2241aca68b6e599444384',1,'odil::Value']]],
  ['duration_5ftype',['duration_type',['../classodil_1_1_association.html#a97c7117f275b9bf936b127519300ae21',1,'odil::Association']]]
];
