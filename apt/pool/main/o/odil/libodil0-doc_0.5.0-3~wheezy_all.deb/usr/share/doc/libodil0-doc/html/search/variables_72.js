var searchData=
[
  ['root',['root',['../classodil_1_1_basic_directory_creator.html#a93b1a6f022c984db2a2f97edd17f59e7',1,'odil::BasicDirectoryCreator']]]
];
