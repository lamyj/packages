var searchData=
[
  ['implicit_5fvr_5flittle_5fendian',['implicit_vr_little_endian',['../classodil_1_1_v_r_finder.html#af0e97ef62dac47bf2f7461ea75088e7b',1,'odil::VRFinder']]],
  ['integers',['Integers',['../classodil_1_1_value.html#a4a09818cb16e71ccc03dd52a43a74e51',1,'odil::Value']]],
  ['is_5fassociated',['is_associated',['../classodil_1_1_association.html#a27a96fe8f5155e555ec51760dbb80e10',1,'odil::Association']]],
  ['is_5fbinary',['is_binary',['../classodil_1_1_element.html#a977f829aca59da3896e108de938126b6',1,'odil::Element']]],
  ['is_5fdata_5fset',['is_data_set',['../classodil_1_1_element.html#aa7cbe83f9f57b7725f0b85e26b00c7a8',1,'odil::Element']]],
  ['is_5fint',['is_int',['../classodil_1_1_element.html#ac778f3bd1a89c6d09fe34e1148cc2d6a',1,'odil::Element']]],
  ['is_5freal',['is_real',['../classodil_1_1_element.html#aafb62f2394998c057ddedf7f35c05311',1,'odil::Element']]],
  ['is_5fstring',['is_string',['../classodil_1_1_element.html#a9b8cf3fb1a55e379265c9dd6dc2eb190',1,'odil::Element']]],
  ['item_5fencoding',['item_encoding',['../classodil_1_1_basic_directory_creator.html#a9258d6c98ab698cb83f1fa5b80167a44',1,'odil::BasicDirectoryCreator::item_encoding()'],['../classodil_1_1_writer.html#aead4664ef2426ad57f342cb2ad63650b',1,'odil::Writer::item_encoding()']]],
  ['itemencoding',['ItemEncoding',['../classodil_1_1_writer.html#a6981282dffa762cc5b74095ecd940c15',1,'odil::Writer']]]
];
