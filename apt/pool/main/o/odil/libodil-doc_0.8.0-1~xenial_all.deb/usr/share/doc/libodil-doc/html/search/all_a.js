var searchData=
[
  ['keep_5fgroup_5flength',['keep_group_length',['../classodil_1_1_reader.html#a201a8a4248686ae62ab91610359681ef',1,'odil::Reader']]],
  ['keyword',['keyword',['../structodil_1_1_elements_dictionary_entry.html#a76a60d39f4d407353781fa99da5194c2',1,'odil::ElementsDictionaryEntry::keyword()'],['../structodil_1_1_u_i_ds_dictionary_entry.html#a6fe1033c4aa25ad3f2712f84971a3db7',1,'odil::UIDsDictionaryEntry::keyword()']]]
];
