var searchData=
[
  ['ncreatescp',['NCreateSCP',['../classodil_1_1_n_create_s_c_p.html',1,'odil']]],
  ['nsetscp',['NSetSCP',['../classodil_1_1_n_set_s_c_p.html',1,'odil']]],
  ['nsetscu',['NSetSCU',['../classodil_1_1_n_set_s_c_u.html',1,'odil']]]
];
