var searchData=
[
  ['itemencoding',['ItemEncoding',['../classodil_1_1_writer.html#a6981282dffa762cc5b74095ecd940c15',1,'odil::Writer']]]
];
