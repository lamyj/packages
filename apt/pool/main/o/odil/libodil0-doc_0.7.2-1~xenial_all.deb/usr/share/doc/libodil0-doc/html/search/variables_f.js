var searchData=
[
  ['vm',['vm',['../structodil_1_1_elements_dictionary_entry.html#a646e63ea53323568ba72e59c5199d41e',1,'odil::ElementsDictionaryEntry']]],
  ['vr',['vr',['../classodil_1_1_element.html#a2a15e3a2e95803b2f44a009dbb9f2a65',1,'odil::Element::vr()'],['../structodil_1_1_elements_dictionary_entry.html#ad3218473d954bbb57b0a50c9cd5885fd',1,'odil::ElementsDictionaryEntry::vr()']]]
];
