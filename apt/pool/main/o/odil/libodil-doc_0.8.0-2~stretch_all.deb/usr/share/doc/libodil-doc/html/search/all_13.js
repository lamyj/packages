var searchData=
[
  ['value',['Value',['../classodil_1_1_value.html',1,'odil']]],
  ['vm',['vm',['../structodil_1_1_elements_dictionary_entry.html#a646e63ea53323568ba72e59c5199d41e',1,'odil::ElementsDictionaryEntry']]],
  ['vr',['vr',['../classodil_1_1_element.html#a2a15e3a2e95803b2f44a009dbb9f2a65',1,'odil::Element::vr()'],['../structodil_1_1_elements_dictionary_entry.html#ad3218473d954bbb57b0a50c9cd5885fd',1,'odil::ElementsDictionaryEntry::vr()']]],
  ['vrfinder',['VRFinder',['../classodil_1_1_v_r_finder.html',1,'odil::VRFinder'],['../classodil_1_1_v_r_finder.html#a21633aaafcc5e2536d0c3dc17731cd77',1,'odil::VRFinder::VRFinder()']]]
];
