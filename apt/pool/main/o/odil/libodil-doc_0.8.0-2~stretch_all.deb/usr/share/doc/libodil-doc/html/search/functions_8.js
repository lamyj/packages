var searchData=
[
  ['ignore',['ignore',['../classodil_1_1_reader.html#af21594808aa7048d6c0b93377bc6b033',1,'odil::Reader']]],
  ['implicit_5fvr_5flittle_5fendian',['implicit_vr_little_endian',['../classodil_1_1_v_r_finder.html#af0e97ef62dac47bf2f7461ea75088e7b',1,'odil::VRFinder']]],
  ['initialize',['initialize',['../classodil_1_1_s_c_p_1_1_data_set_generator.html#a1007fcf15f3ed660aa3cd09006460b12',1,'odil::SCP::DataSetGenerator']]],
  ['is_5fassociated',['is_associated',['../classodil_1_1_association.html#aa5627aa1a5948c2bef5ee651ed2402fd',1,'odil::Association']]],
  ['is_5fbinary',['is_binary',['../classodil_1_1_data_set.html#a733e000e641a8ab29a3bd3bc1bb8752f',1,'odil::DataSet::is_binary()'],['../classodil_1_1_element.html#aec2ce24d6d62ee82bd911045366b6272',1,'odil::Element::is_binary()']]],
  ['is_5fdata_5fset',['is_data_set',['../classodil_1_1_data_set.html#af496a380ee7e8c329c3c488089a047da',1,'odil::DataSet::is_data_set()'],['../classodil_1_1_element.html#a9df3b5a15e023dec3c7bb33e2fcdef10',1,'odil::Element::is_data_set()']]],
  ['is_5fint',['is_int',['../classodil_1_1_data_set.html#a33587f74171399e2f345240ad46bad89',1,'odil::DataSet::is_int()'],['../classodil_1_1_element.html#afcd57a1a30e4d7cb4a6544bf9573dee6',1,'odil::Element::is_int()']]],
  ['is_5fprivate',['is_private',['../classodil_1_1_tag.html#ad13892f8e29f6a2712a22cd8f8505c0a',1,'odil::Tag']]],
  ['is_5freal',['is_real',['../classodil_1_1_data_set.html#a17d6db084c08fbb9c8ed9a65c5252d65',1,'odil::DataSet::is_real()'],['../classodil_1_1_element.html#a10a288ada24f3082c45827f7df25128b',1,'odil::Element::is_real()']]],
  ['is_5fstring',['is_string',['../classodil_1_1_data_set.html#af96d04f5363204e975a6371f7c027c0c',1,'odil::DataSet::is_string()'],['../classodil_1_1_element.html#a65e7d395d3cce9d0ea779194656b31d7',1,'odil::Element::is_string()']]]
];
