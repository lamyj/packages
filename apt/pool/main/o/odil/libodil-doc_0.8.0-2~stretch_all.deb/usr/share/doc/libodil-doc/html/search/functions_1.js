var searchData=
[
  ['basicdirectorycreator',['BasicDirectoryCreator',['../classodil_1_1_basic_directory_creator.html#acfbc5677aa1f1f3d2110c2a3f9daee43',1,'odil::BasicDirectoryCreator']]],
  ['begin',['begin',['../classodil_1_1_data_set.html#a15b2da3fb1cdda38e4c542546d8e33fb',1,'odil::DataSet']]]
];
