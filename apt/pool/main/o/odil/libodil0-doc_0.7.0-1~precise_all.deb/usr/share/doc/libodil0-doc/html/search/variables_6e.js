var searchData=
[
  ['name',['name',['../structodil_1_1_elements_dictionary_entry.html#afd991e849053d43e202b11bbb5bdeb38',1,'odil::ElementsDictionaryEntry::name()'],['../structodil_1_1_u_i_ds_dictionary_entry.html#a82c66b73110eec5b48b9c3c409c628ca',1,'odil::UIDsDictionaryEntry::name()']]]
];
