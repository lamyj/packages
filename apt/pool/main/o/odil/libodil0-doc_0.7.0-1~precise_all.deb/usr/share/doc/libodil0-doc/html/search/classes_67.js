var searchData=
[
  ['getscp',['GetSCP',['../classodil_1_1_get_s_c_p.html',1,'odil']]],
  ['getscu',['GetSCU',['../classodil_1_1_get_s_c_u.html',1,'odil']]]
];
