var searchData=
[
  ['ycoordinatescenterpixelviewangle',['YCoordinatesCenterPixelViewAngle',['../namespaceodil_1_1registry.html#a901c54b65442087337e0c65bed95ec7d',1,'odil::registry']]],
  ['yfocuscenter',['YFocusCenter',['../namespaceodil_1_1registry.html#a69e4c0a27d37e368c53d5e5deb6676ab',1,'odil::registry']]],
  ['yoffsetinslidecoordinatesystem',['YOffsetInSlideCoordinateSystem',['../namespaceodil_1_1registry.html#a98c3900e9d83be30afd8f85680d05998',1,'odil::registry']]]
];
