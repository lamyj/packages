var searchData=
[
  ['byte_5fordering',['byte_ordering',['../classodil_1_1_reader.html#a5d95804d2ed191494796eeaa0d015a74',1,'odil::Reader::byte_ordering()'],['../classodil_1_1_writer.html#a9fe9fae6d7bb7cce66851c5ef0a1fd1b',1,'odil::Writer::byte_ordering()']]]
];
