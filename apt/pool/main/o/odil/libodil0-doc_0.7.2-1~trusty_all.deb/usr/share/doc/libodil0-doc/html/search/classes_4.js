var searchData=
[
  ['findscp',['FindSCP',['../classodil_1_1_find_s_c_p.html',1,'odil']]],
  ['findscu',['FindSCU',['../classodil_1_1_find_s_c_u.html',1,'odil']]]
];
