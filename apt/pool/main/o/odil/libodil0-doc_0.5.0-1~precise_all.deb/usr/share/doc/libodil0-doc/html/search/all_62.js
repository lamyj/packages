var searchData=
[
  ['basicdirectorycreator',['BasicDirectoryCreator',['../classodil_1_1_basic_directory_creator.html',1,'odil']]],
  ['binary',['Binary',['../classodil_1_1_value.html#a50468b96116e054f568b1874a708b53a',1,'odil::Value']]],
  ['byte_5fordering',['byte_ordering',['../classodil_1_1_reader.html#a5d95804d2ed191494796eeaa0d015a74',1,'odil::Reader::byte_ordering()'],['../classodil_1_1_writer.html#a9fe9fae6d7bb7cce66851c5ef0a1fd1b',1,'odil::Writer::byte_ordering()']]]
];
