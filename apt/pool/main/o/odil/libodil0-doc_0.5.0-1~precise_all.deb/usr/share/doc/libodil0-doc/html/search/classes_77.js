var searchData=
[
  ['writer',['Writer',['../classodil_1_1_writer.html',1,'odil']]]
];
