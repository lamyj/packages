var searchData=
[
  ['transfer_5fsyntax',['transfer_syntax',['../classodil_1_1_reader.html#a6c4105a3e8661fcb89db67d2b8f8094f',1,'odil::Reader']]],
  ['transfer_5fsyntaxes',['transfer_syntaxes',['../structodil_1_1_association_parameters_1_1_presentation_context.html#acca074b98b0959c9a7cfd4fb034898f2',1,'odil::AssociationParameters::PresentationContext']]],
  ['type',['type',['../structodil_1_1_association_parameters_1_1_user_identity.html#a1b7b5fb7f1e8ca706ff7d88c35bf3c29',1,'odil::AssociationParameters::UserIdentity::type()'],['../structodil_1_1_u_i_ds_dictionary_entry.html#ae02685a0d0d6b42363620a787b69e93c',1,'odil::UIDsDictionaryEntry::type()']]]
];
