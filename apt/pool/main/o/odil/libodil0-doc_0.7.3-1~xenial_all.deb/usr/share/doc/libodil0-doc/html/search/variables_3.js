var searchData=
[
  ['default_5ffinders',['default_finders',['../classodil_1_1_v_r_finder.html#ae43d5072175e8bcbbff612db9fc05cc0',1,'odil::VRFinder']]],
  ['default_5frecord_5fkeys',['default_record_keys',['../classodil_1_1_basic_directory_creator.html#a6e63a46262feb1619d178688237022b1',1,'odil::BasicDirectoryCreator']]]
];
