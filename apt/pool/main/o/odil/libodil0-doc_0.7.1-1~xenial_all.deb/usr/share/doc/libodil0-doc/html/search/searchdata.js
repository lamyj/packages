var indexSectionsWithContent =
{
  0: "_abcdefghikmnoprstuvw~",
  1: "abdefgmprstuvw",
  2: "abcdefghimnoprstuvw~",
  3: "_abdefgiknprstuv",
  4: "bcdfgimrs",
  5: "dirt",
  6: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Pages"
};

