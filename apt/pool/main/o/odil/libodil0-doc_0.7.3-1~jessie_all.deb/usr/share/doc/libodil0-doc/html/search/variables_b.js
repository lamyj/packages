var searchData=
[
  ['reason',['reason',['../classodil_1_1_association_aborted.html#af76cb2e91011ab5b9b91a0e9e0d09206',1,'odil::AssociationAborted']]],
  ['result',['result',['../structodil_1_1_association_parameters_1_1_presentation_context.html#a68fdc3a2b15d3df1a28f6093c7dddeb3',1,'odil::AssociationParameters::PresentationContext']]],
  ['root',['root',['../classodil_1_1_basic_directory_creator.html#a93b1a6f022c984db2a2f97edd17f59e7',1,'odil::BasicDirectoryCreator']]]
];
