var searchData=
[
  ['tag',['Tag',['../classodil_1_1_tag.html',1,'odil']]],
  ['tag',['Tag',['../classodil_1_1_tag.html#a9bb871a3dfd0869c38137d1d75be03f7',1,'odil::Tag::Tag(uint16_t group, uint16_t element)'],['../classodil_1_1_tag.html#a00d457758066374a346990d5c56b6aaf',1,'odil::Tag::Tag(uint32_t tag=0)'],['../classodil_1_1_tag.html#aab3feea935d659eee7098b8486445774',1,'odil::Tag::Tag(std::string const &amp;name)'],['../classodil_1_1_tag.html#a0507475eb88b73ad520c78af799adee1',1,'odil::Tag::Tag(char const *name)']]],
  ['tojsonvisitor',['ToJSONVisitor',['../structodil_1_1_to_j_s_o_n_visitor.html',1,'odil']]],
  ['toxmlvisitor',['ToXMLVisitor',['../structodil_1_1_to_x_m_l_visitor.html',1,'odil']]],
  ['transfer_5fsyntax',['transfer_syntax',['../classodil_1_1_reader.html#a6c4105a3e8661fcb89db67d2b8f8094f',1,'odil::Reader']]],
  ['type',['Type',['../classodil_1_1_elements_dictionary_key.html#a00476507d06ed38282895077cc5785c6',1,'odil::ElementsDictionaryKey::Type()'],['../classodil_1_1_value.html#a7dce7c628fe81f1e3aa83939c2387364',1,'odil::Value::Type()']]]
];
