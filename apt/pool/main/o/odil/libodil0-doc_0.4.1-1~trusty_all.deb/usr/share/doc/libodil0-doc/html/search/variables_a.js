var searchData=
[
  ['transfer_5fsyntax',['transfer_syntax',['../classodil_1_1_reader.html#a6c4105a3e8661fcb89db67d2b8f8094f',1,'odil::Reader']]]
];
