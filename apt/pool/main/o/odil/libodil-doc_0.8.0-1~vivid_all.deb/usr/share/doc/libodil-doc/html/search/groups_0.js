var searchData=
[
  ['default_20class_20operations',['Default class operations',['../group__default__operations.html',1,'']]]
];
