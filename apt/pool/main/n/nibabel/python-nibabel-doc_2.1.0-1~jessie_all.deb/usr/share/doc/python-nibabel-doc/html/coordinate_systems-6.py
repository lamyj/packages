M = epi_img.affine[:3, :3]
abc = epi_img.affine[:3, 3]
