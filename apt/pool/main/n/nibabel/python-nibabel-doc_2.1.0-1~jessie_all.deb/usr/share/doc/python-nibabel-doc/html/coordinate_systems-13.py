anat_vox_center = (np.array(anat_img_data.shape) - 1) / 2.
anat_vox_center
# array([ 28. ,  33. ,  27.5])
