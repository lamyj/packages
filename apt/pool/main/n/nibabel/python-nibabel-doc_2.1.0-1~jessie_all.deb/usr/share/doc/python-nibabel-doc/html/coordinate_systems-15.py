one_vox_axis_0 = [1, 0, 0]
apply_affine(scaling_affine, one_vox_axis_0)
# array([3, 0, 0])
