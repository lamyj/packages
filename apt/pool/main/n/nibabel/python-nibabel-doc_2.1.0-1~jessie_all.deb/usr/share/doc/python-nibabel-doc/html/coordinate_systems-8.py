epi_vox_center = (np.array(epi_img_data.shape) - 1) / 2.
f(epi_vox_center[0], epi_vox_center[1], epi_vox_center[2])
# array([ 0.   , -4.205,  8.453])
