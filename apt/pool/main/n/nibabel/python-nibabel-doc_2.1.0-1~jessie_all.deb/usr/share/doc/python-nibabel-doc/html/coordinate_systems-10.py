from nibabel.affines import apply_affine
apply_affine(epi_img.affine, epi_vox_center)
# array([ 0.   , -4.205,  8.453])
