epi_img.affine.dot(list(epi_vox_center) + [1])
# array([ 0.   , -4.205,  8.453,  1.   ])
