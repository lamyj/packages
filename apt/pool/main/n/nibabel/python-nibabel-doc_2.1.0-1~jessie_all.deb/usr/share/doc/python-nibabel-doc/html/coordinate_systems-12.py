apply_affine(epi_vox2anat_vox, epi_vox_center)
# array([ 28.364,  31.562,  36.165])
