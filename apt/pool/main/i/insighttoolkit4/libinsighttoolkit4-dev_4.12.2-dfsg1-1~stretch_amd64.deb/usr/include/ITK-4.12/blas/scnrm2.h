extern v3p_netlib_doublereal v3p_netlib_scnrm2_(
  v3p_netlib_integer *n,
  v3p_netlib_complex *x,
  v3p_netlib_integer *incx
  );
