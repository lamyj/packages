#ifndef vcl_set_h_
#define vcl_set_h_

#include <set>
#include "vcl_compiler.h"

#endif // vcl_set_h_
