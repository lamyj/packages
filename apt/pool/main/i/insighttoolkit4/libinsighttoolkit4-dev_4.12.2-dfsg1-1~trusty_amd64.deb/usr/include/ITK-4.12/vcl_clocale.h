#ifndef vcl_clocale_h_
#define vcl_clocale_h_

#include <clocale>
#include "vcl_compiler.h"

#endif // vcl_clocale_h_
