/*: Set-up routine for dgpfa_ */
extern int v3p_netlib_setdgpfa_(
  v3p_netlib_doublereal *trigs,
  v3p_netlib_integer v3p_netlib_const *n,
  v3p_netlib_integer *npqr,
  v3p_netlib_integer *info
  );
