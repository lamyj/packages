#ifndef vcl_stack_h_
#define vcl_stack_h_

#include <stack>
#include "vcl_compiler.h"

#endif // vcl_stack_h_
