#ifndef vcl_cwctype_h_
#define vcl_cwctype_h_

#include <cwctype>
#include "vcl_compiler.h"

#endif // vcl_cwctype_h_
