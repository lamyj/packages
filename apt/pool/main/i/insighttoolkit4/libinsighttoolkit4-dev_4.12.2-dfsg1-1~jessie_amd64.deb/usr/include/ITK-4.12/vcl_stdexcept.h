#ifndef vcl_stdexcept_h_
#define vcl_stdexcept_h_

#include <stdexcept>
#include "vcl_compiler.h"

#endif // vcl_stdexcept_h_
