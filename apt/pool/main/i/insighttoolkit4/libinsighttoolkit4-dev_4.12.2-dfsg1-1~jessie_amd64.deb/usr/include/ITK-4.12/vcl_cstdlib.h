#ifndef vcl_cstdlib_h_
#define vcl_cstdlib_h_

#include <cstdlib>
#include "vcl_compiler.h"

#endif // vcl_cstdlib_h_
