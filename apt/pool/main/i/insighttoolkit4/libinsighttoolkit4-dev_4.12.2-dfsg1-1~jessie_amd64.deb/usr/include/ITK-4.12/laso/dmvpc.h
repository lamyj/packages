extern int v3p_netlib_dmvpc_(
  v3p_netlib_integer *nblock,
  v3p_netlib_doublereal *bet,
  v3p_netlib_integer *maxj,
  v3p_netlib_integer *j,
  v3p_netlib_doublereal *s,
  v3p_netlib_integer *number,
  v3p_netlib_doublereal *resnrm,
  v3p_netlib_doublereal *orthcf,
  v3p_netlib_doublereal *rv
  );
