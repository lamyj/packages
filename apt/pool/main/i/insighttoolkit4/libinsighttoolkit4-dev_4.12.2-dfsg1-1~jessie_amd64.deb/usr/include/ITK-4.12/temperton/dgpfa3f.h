extern int v3p_netlib_dgpfa3f_(
  v3p_netlib_doublereal *a,
  v3p_netlib_doublereal *b,
  v3p_netlib_doublereal *trigs,
  v3p_netlib_integer *inc,
  v3p_netlib_integer *jump,
  v3p_netlib_integer *n,
  v3p_netlib_integer *mm,
  v3p_netlib_integer *lot,
  v3p_netlib_integer *isign
  );
