extern v3p_netlib_E_f v3p_netlib_urand_(
  v3p_netlib_integer *iy
  );
