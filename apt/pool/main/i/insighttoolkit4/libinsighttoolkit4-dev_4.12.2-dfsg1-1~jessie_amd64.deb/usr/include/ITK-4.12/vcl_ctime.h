#ifndef vcl_ctime_h_
#define vcl_ctime_h_

// ??  This is a customization that is not part of the
// macro used to auto generate this header file
#ifndef VCL_WIN32
#include <ctime>
#include <sys/times.h>
#endif

#include "vcl_compiler.h"

#endif // vcl_ctime_h_
