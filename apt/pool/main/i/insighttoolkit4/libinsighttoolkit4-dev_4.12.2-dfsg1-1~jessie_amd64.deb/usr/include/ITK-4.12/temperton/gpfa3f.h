extern int v3p_netlib_gpfa3f_(
  v3p_netlib_real *a,
  v3p_netlib_real *b,
  v3p_netlib_real *trigs,
  v3p_netlib_integer *inc,
  v3p_netlib_integer *jump,
  v3p_netlib_integer *n,
  v3p_netlib_integer *mm,
  v3p_netlib_integer *lot,
  v3p_netlib_integer *isign
  );
