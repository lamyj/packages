/*: Set-up routine for gpfa_ */
extern int v3p_netlib_setgpfa_(
  v3p_netlib_real *trigs,
  v3p_netlib_integer v3p_netlib_const *n,
  v3p_netlib_integer *npqr,
  v3p_netlib_integer *info
  );
