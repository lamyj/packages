#ifndef vcl_csignal_h_
#define vcl_csignal_h_

#include <csignal>
#include "vcl_compiler.h"

#endif // vcl_csignal_h_
