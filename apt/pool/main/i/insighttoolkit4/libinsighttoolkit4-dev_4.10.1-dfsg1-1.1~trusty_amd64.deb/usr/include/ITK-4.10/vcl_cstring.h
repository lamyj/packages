#ifndef vcl_cstring_h_
#define vcl_cstring_h_

#include <cstring>
#include "vcl_compiler.h"

#endif // vcl_cstring_h_
