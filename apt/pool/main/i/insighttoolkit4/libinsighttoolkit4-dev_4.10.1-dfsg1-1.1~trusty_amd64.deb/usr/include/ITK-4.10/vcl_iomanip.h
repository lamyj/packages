#ifndef vcl_iomanip_h_
#define vcl_iomanip_h_

#include <iomanip>
#include "vcl_compiler.h"

#endif // vcl_iomanip_h_
