#ifndef vcl_bitset_h_
#define vcl_bitset_h_

#include <bitset>
#include "vcl_compiler.h"

#endif // vcl_bitset_h_
