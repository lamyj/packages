#ifndef vcl_functional_h_
#define vcl_functional_h_

#include <functional>
#include "vcl_compiler.h"

#endif // vcl_functional_h_
