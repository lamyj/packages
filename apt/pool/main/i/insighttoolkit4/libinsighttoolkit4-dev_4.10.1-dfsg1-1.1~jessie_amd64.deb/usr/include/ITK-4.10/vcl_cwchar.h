#ifndef vcl_cwchar_h_
#define vcl_cwchar_h_

#include <cwchar>
#include "vcl_compiler.h"

#endif // vcl_cwchar_h_
