#ifndef vcl_iosfwd_h_
#define vcl_iosfwd_h_

#include <iosfwd>
#include "vcl_compiler.h"

#endif // vcl_iosfwd_h_
