#ifndef vcl_limits_h_
#define vcl_limits_h_

#include <limits>
#include "vcl_compiler.h"

#endif // vcl_limits_h_
